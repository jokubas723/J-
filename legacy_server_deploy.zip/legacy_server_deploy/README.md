# Legacy Client Lab — serverio tyrimo karkasas

Tai galima įkelti į GitHub ir dislokuoti kaip Docker Web Service platformoje, palaikančioje Docker (pvz., Render). Tai diagnostinis HTTP karkasas, o ne veikiantis senos Roblox versijos žaidimo serveris.

## Vietinis bandymas

Reikia Python 3.10+:

```bash
python server.py
```

Tada atverk `http://127.0.0.1:8080/healthz`.

## Diegimas Render

1. Įkelk šio aplanko failus į savo GitHub repozitoriją.
2. Render pasirink „New +“ → „Blueprint“ ir prijunk repozitoriją.
3. Patvirtink `render.yaml` konfigūraciją.
4. Po diegimo atverk suteiktą URL su `/healthz`.

Nemokamas planas gali užmigti po neveiklumo. Šis HTTP serveris neįgyvendina senojo žaidimo sesijos, autentifikavimo, RakNet paketo formato ar pasaulio sinchronizavimo, todėl APK kol kas neprijungs ir žaisti neleis.

## APK suderinamumo pastaba

Pateiktame APK aptikta tik `lib/armeabi-v7a/libroblox.so` (32 bitų ARM). Dalis naujų Android įrenginių vis dar palaiko 32 bitų programas, bet 64-bitų-only įrenginiai tokios bibliotekos paleisti negali. Pakeitus manifestą įrenginio 64 bitų palaikymo neatsiras: tam reikėtų 64 bitų vietinės bibliotekos šaltinio arba naujos versijos. APK taip pat reikia atskirai patikrinti ir pasirašyti po bet kokio pakeitimo.
