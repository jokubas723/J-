#!/usr/bin/env python3
"""Legacy client compatibility research server. Not a playable game server yet."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import json, os, time

HOST = '0.0.0.0'
PORT = int(os.environ.get('PORT', '8080'))
STARTED = time.time()

class Handler(BaseHTTPRequestHandler):
    server_version = 'LegacyClientLab/0.2'
    def send_json(self, status, payload):
        data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)
    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ('/', '/health', '/healthz'):
            return self.send_json(200, {'ok': True, 'service': 'LegacyClientLab', 'mode': 'diagnostic-only', 'playable': False, 'uptime_seconds': int(time.time()-STARTED), 'message': 'Server is online, but the 2014 game-session protocol is not implemented.'})
        if u.path == '/api/diagnostic':
            return self.send_json(200, {'received_path': u.path, 'query': parse_qs(u.query), 'playable': False, 'missing': ['legacy HTTP response formats', 'session/authentication flow', 'RakNet game protocol', 'world replication']})
        if u.path.lower() in ('/game/join.ashx', '/game/placelauncher.ashx', '/game/gameserver.ashx'):
            return self.send_json(501, {'error': 'not_implemented', 'message': 'Endpoint recorded for compatibility research only; this server cannot create a playable session.', 'path': u.path})
        return self.send_json(404, {'error': 'not_found', 'path': u.path})
    def do_POST(self):
        length = min(int(self.headers.get('Content-Length', '0')), 1024*1024)
        body = self.rfile.read(length) if length else b''
        u = urlparse(self.path)
        print(json.dumps({'time': int(time.time()), 'method': 'POST', 'path': u.path, 'body_bytes': len(body)}), flush=True)
        if u.path.lower() in ('/game/join.ashx', '/game/placelauncher.ashx', '/game/gameserver.ashx'):
            return self.send_json(501, {'error': 'not_implemented', 'message': 'Request logged, but the legacy game-session protocol is not implemented.', 'path': u.path, 'received_bytes': len(body)})
        return self.send_json(404, {'error': 'not_found', 'path': u.path})
    def log_message(self, fmt, *args):
        print('%s - %s' % (self.address_string(), fmt % args), flush=True)

if __name__ == '__main__':
    print(f'LegacyClientLab diagnostic server listening on {HOST}:{PORT}', flush=True)
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
